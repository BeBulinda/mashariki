<?php get_header(); ?>
<div class="container">
    		<div class="site-aligner">
			<?php woocommerce_content(); ?>
		   </div><!-- site-aligner -->
    </div><!-- content -->
     
<?php get_footer(); ?>