<?php
/*
=================================================
Header Box Wrapper Chooser Hooks
=================================================
*/

add_action('flat_responsive_wrapper_choose', 'flat_responsive_wrapper_choose_fnc');

/*
=================================================
Social Icons on Top Display Hooks
=================================================
*/

add_action('flat_responsive_social_icons_top', 'flat_responsive_social_icons_top_fnc');

/*
=================================================
Header Main Display Hooks
=================================================
*/
add_action('flat_responsive_header', 'flat_responsive_header_fnc');

 ?>