<?php

namespace Kirki;
use Kirki\Styles\Customizer;
use Kirki\Styles\Frontend;

class Styles {

	public function __construct() {

		$customizer_styles = new Customizer();
		$frontend_styles   = new Frontend();

	}

}
