<?php
/**
 * Displays a status post
 */
?>
        <div class="ti-status-post"><?php the_content(); ?></div>
