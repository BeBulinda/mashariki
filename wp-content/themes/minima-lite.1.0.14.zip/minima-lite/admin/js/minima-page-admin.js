jQuery(document).ready(function($){
    console.log("page admin ready");
})