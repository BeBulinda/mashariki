<?php
/**
 * Displays a link post
 */
?>
    <?php the_content(); ?>
