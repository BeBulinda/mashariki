<?php
/**
 * Displays a quote post
 */
?>
    <?php the_content(); ?>
