<?php
/**
 * Displays a video post
 */
the_content(); ?>
