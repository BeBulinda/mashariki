<div id="ti-postcontent-sidebar" class="row ti-content-sidebar">
    <?php dynamic_sidebar('sidebar-4'); ?>
</div>