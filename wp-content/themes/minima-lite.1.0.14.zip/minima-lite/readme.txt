Minima Lite WordPress theme, Copyright (C) 2013 Minima Themes.
Minima Lite WordPress theme is licensed under the GPL.
Following are license details of all resources bundled with Minima Lite WordPress Theme

jQuery UI - MIT License - https://jquery.org/license/
admin/css/jquery-ui-1.8.21.custom.css
admin/css/images/
admin/js/jquery-ui-1.10.3.custom.min.js

TipTip - MIT & GPL Dual Licensed- https://github.com/drewwilson/TipTip
admin/css/tipTip.css
admin/js/jquery.tipTip.minified.js

jQuery Json - MIT License https://code.google.com/p/jquery-json/
admin/json.js

jQuery DoubleTap to go - MIT License http://osvaldas.info/drop-down-navigation-responsive-and-touch-friendlyhttp://osvaldas.info/examples/drop-down-navigation-touch-friendly-and-responsive/doubletaptogo.js
js/jquery.dbltaptogo.js

jQuery Touch swipe - MIT & GPL Dual Licensed https://github.com/mattbryson/TouchSwipe-Jquery-Plugin
js/jquery.touchSwipe.js


I have designed and developed rest of all bundled CSS scripts, JavaScript scripts, Images and Icon set. They are covered under GPL license.

User Guide -
Go to "Apearance"->"Minima Options"->"Help" for detailed documentation and guides with pictures.