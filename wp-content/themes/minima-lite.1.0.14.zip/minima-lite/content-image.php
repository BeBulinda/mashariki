<?php
/**
 * Displays a image post
 */
?>
    <?php the_content(); ?>
