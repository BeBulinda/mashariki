<?php
/**
 * Displays a audio post
 */
?>
    <?php the_content(); ?>
