<?php
/**
 * Displays a normal post
 */
?>
        <div class="ti-aside-post"><?php the_content(); ?></div>