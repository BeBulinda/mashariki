<div id="ti-left-sidebar" class="span3">
    <?php dynamic_sidebar('sidebar-1'); ?>
</div>