var wow = new WOW(
	{
		offset: 0, // distance to the element when triggering the animation (default is 0)
		mobile: false // trigger animations on mobile devices (true is default)
	}
); 

wow.init();