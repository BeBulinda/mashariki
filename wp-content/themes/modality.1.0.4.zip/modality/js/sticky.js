var stickup=jQuery.noConflict();
	stickup(function($) {
        $(document).ready( function() {
          $('#header-holder').stickUp({ 
			topMargin: 'auto' 
		  });
	});
});