<?php 
/**
 * @package Modality
 */
?>
<div <?php post_class('post-wrapper wow fadeIn'); ?> data-wow-delay="0.5s">
	<?php get_template_part( 'post', 'formats');?>
</div>