<?php get_header(); 

 	get_template_part('templates/content', 'single');
 	
			 get_sidebar(); ?>
	    	</div><!-- /.row-->
		</div><!-- /.content -->
	</div><!-- /.wrap -->
	<?php get_footer(); ?>