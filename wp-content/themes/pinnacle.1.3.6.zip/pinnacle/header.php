<?php get_template_part('templates/head'); ?>
	<body <?php body_class(); ?> >
		<div id="wrapper" class="container">
		  	<?php do_action('get_header');
		    get_template_part('templates/header'); ?>
			<div class="wrap contentclass" role="document">